import { useState, useMemo, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mic, Paperclip, CornerDownLeft, Check, Pencil, X, FileText, AudioLines,
  Image as ImageIcon, Radio, Square,
} from "lucide-react";

/* ---------- Tokens ---------- */
const T = {
  bg: "#08090C", card: "#111319", line: "#1E222D",
  em: "#00F5A0", amber: "#F59E0B", white: "#F9FAFB", mute: "#9CA3AF",
};
const SANS = "Inter, Geist, system-ui, -apple-system, 'Segoe UI', sans-serif";
const MONO = "'JetBrains Mono', 'Fira Code', ui-monospace, SFMono-Regular, Menlo, monospace";

const INITIAL = [
  { id: 1, who: "Mama", time: "12:04", type: "Voice Note", status: "held",
    text: "Are you still coming for dinner? Your aunt arrives at eight.", draft: "Running a little late, I'll be there by 8:30. Save me a plate." },
  { id: 2, who: "Hamza Khan", time: "11:58", type: "Text", status: "auto",
    text: "Did the meeting move to 3 pm?", draft: "" },
  { id: 3, who: "Ayesha", time: "11:41", type: "Image", status: "held",
    text: "[image] a gold link bracelet on a velvet tray, price tag reads 18,500.", draft: "That's lovely. Can you hold it until Friday?" },
  { id: 4, who: "Bilal", time: "10:12", type: "Voice Note", status: "voice",
    text: "Asked for the invoice number. Replied in your voice: INV-2291.", draft: "" },
  { id: 5, who: "Sana", time: "09:30", type: "Text", status: "auto",
    text: "Thanks for the update, talk tomorrow.", draft: "" },
  { id: 6, who: "Office Group", time: "09:02", type: "Text", status: "auto",
    text: "Reminder: stand-up at 9:15.", draft: "" },
];

const CHIPS = [
  { id: "summ", label: "Summarize unread voice notes" },
  { id: "draft", label: "Draft delay apology to Mama" },
  { id: "pause", label: "Pause auto-reply for 1 hour" },
];

const RESP = {
  summ: ["Two voice notes are unread.", "Mama asks if you're still coming to dinner.", "Bilal wanted the invoice number, already answered."],
  draft: ["Drafting for Mama.", "\"Running a little late, I'll be there by 8:30.\"", "Held for your approval."],
  pause: ["Auto-pilot paused for one hour.", "Incoming messages will wait in the queue."],
  free: ["Understood.", "I've queued that instruction and will confirm once it's done."],
};

const STATUS = {
  auto: { label: "Auto-Replied", c: T.em },
  voice: { label: "Voice Synthesized", c: "#5EEAD4" },
  held: { label: "Held for Review", c: T.amber },
  sent: { label: "Approved & Sent", c: T.em },
  rejected: { label: "Rejected", c: T.mute },
};
const TYPE_ICON = { Text: FileText, "Voice Note": AudioLines, Image: ImageIcon };

/* ---------- n8n backend ----------
   Set VITE_N8N_BASE_URL in .env, e.g. https://your-n8n-host/webhook
   Leave it empty to run the dashboard on sample data (demo mode). */
const BASE = (import.meta.env.VITE_N8N_BASE_URL || "").replace(/\/$/, "");
const LIVE = Boolean(BASE);
const apiGet = async () => {
  const r = await fetch(`${BASE}/aura-activity`);
  if (!r.ok) throw new Error("activity " + r.status);
  return r.json();
};
const apiPost = async (body) => {
  const r = await fetch(`${BASE}/aura-action`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || "action " + r.status);
  return data;
};
const clock = (iso) => new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });

/* ---------- Switch ---------- */
function Switch({ label, on, onChange }) {
  return (
    <button
      role="switch" aria-checked={on} onClick={() => onChange(!on)}
      className="flex items-center gap-2.5 rounded-md border px-3 py-1.5 text-sm transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-300"
      style={{ borderColor: on ? "rgba(0,245,160,.35)" : T.line, background: on ? "rgba(0,245,160,.06)" : "transparent", color: on ? T.white : T.mute }}
    >
      <span className="relative h-4 w-7 rounded-full" style={{ background: on ? T.em : "#2A2F3C" }}>
        <motion.span
          className="absolute top-0.5 h-3 w-3 rounded-full"
          style={{ background: on ? "#04130D" : "#6B7280" }}
          animate={{ left: on ? 14 : 2 }} transition={{ type: "spring", stiffness: 500, damping: 30 }}
        />
      </span>
      {label}
    </button>
  );
}

function Stat({ label, value, tone }) {
  return (
    <div className="flex items-baseline gap-2 rounded-md border px-3 py-1.5"
      style={{ borderColor: tone ? "rgba(245,158,11,.4)" : T.line, background: tone ? "rgba(245,158,11,.07)" : "transparent" }}>
      <span className="text-xs" style={{ color: T.mute }}>{label}</span>
      <motion.span key={value} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
        className="text-sm font-medium" style={{ fontFamily: MONO, color: tone || T.white }}>{value}</motion.span>
    </div>
  );
}

/* ---------- Fluid waveform visualizer ---------- */
const W = 800, H = 240, MID = 120;
function wavePath(amp, phase, freq, skew) {
  let d = "";
  for (let x = 0; x <= W; x += 10) {
    const t = x / W;
    const env = Math.pow(Math.sin(Math.PI * Math.pow(t, skew)), 1.4); // asymmetric envelope
    const y = MID + amp * env * Math.sin(t * freq * Math.PI * 2 + phase);
    d += (x ? "L" : "M") + x + " " + y.toFixed(1) + " ";
  }
  return d;
}
const PHASE_CFG = {
  idle: { amp: 10, dur: 7 },
  listening: { amp: 52, dur: 1.6 },
  processing: { amp: 34, dur: 2.2 },
  speaking: { amp: 44, dur: 2.8 },
};

function Waveform({ phase }) {
  const { amp, dur } = PHASE_CFG[phase];
  const layers = useMemo(() => [0, 1, 2].map((i) => {
    const f = 2.2 + i * 0.9, s = 0.75 + i * 0.22, a = amp * (1 - i * 0.28);
    return [0, 1.6, 3.2, 4.8, 6.28].map((p) => wavePath(a, p + i, f, s));
  }), [amp]);
  const spin = phase === "processing" || phase === "speaking";
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`Voice visualizer: ${phase}`}>
      <defs>
        <motion.linearGradient id="fluid" gradientUnits="userSpaceOnUse" spreadMethod="reflect"
          x1={0} y1={0} x2={W} y2={0}
          animate={spin ? { x1: [0, W, 0], x2: [W, W * 2, W] } : { x1: 0, x2: W }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}>
          <stop offset="0" stopColor="#00F5A0" />
          <stop offset=".5" stopColor="#5EEAD4" />
          <stop offset="1" stopColor="#F59E0B" />
        </motion.linearGradient>
        <filter id="glow" x="-10%" y="-50%" width="120%" height="200%">
          <feGaussianBlur stdDeviation="5" />
        </filter>
      </defs>
      {phase === "listening" && [0, 1, 2].map((i) => (
        <motion.ellipse key={i} cx={W * 0.42} cy={MID} fill="none" stroke={T.em} strokeWidth="1.5"
          initial={{ rx: 20, ry: 10, opacity: 0.8 }}
          animate={{ rx: 360, ry: 110, opacity: 0 }}
          transition={{ duration: 2.4, repeat: Infinity, delay: i * 0.8, ease: "easeOut" }} />
      ))}
      <line x1="0" x2={W} y1={MID} y2={MID} stroke={T.line} strokeDasharray="2 6" />
      {layers.map((frames, i) => (
        <g key={i} opacity={1 - i * 0.3}>
          {i === 0 && (
            <motion.path d={frames[0]} animate={{ d: frames }} fill="none" stroke="url(#fluid)"
              strokeWidth="8" filter="url(#glow)" opacity=".55"
              transition={{ duration: dur, repeat: Infinity, ease: "easeInOut" }} />
          )}
          <motion.path d={frames[0]} animate={{ d: frames }} fill="none"
            stroke={phase === "listening" ? T.em : "url(#fluid)"} strokeWidth={i === 0 ? 2.5 : 1.5} strokeLinecap="round"
            transition={{ duration: dur * (1 + i * 0.25), repeat: Infinity, ease: "easeInOut" }} />
        </g>
      ))}
    </svg>
  );
}

/* ---------- Message card ---------- */
function Card({ m, active, onSelect, onApprove, onEditSave }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(m.draft);
  const st = STATUS[m.status];
  const Icon = TYPE_ICON[m.type];
  return (
    <motion.li layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }}
      whileHover={{ x: 2 }}
      onClick={() => onSelect(m.id)}
      className="cursor-pointer rounded-lg border p-3.5"
      style={{ background: T.card, borderColor: active ? "rgba(0,245,160,.45)" : T.line,
        boxShadow: m.status === "held" ? "inset 2px 0 0 " + T.amber : "none" }}>
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium" style={{ color: T.white }}>{m.who}</span>
        <span className="text-xs" style={{ fontFamily: MONO, color: T.mute }}>{m.time}</span>
        <span className="ml-auto flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px]"
          style={{ fontFamily: MONO, background: "#181B24", color: T.mute }}>
          <Icon size={11} /> {m.type}
        </span>
      </div>
      <p className="mt-2 text-sm leading-relaxed" style={{ color: T.mute }}>{m.text}</p>
      <div className="mt-3">
        <span className="rounded-full border px-2.5 py-0.5 text-[11px]"
          style={{ fontFamily: MONO, color: st.c, borderColor: st.c + "55", background: st.c + "12" }}>
          {st.label}
        </span>
      </div>
      <AnimatePresence initial={false}>
        {m.status === "held" && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="mt-3 rounded-md border p-2.5 text-sm" style={{ borderColor: T.line, background: "#0C0E13" }}>
              <div className="mb-1 text-[11px]" style={{ fontFamily: MONO, color: T.amber }}>proposed reply</div>
              {editing ? (
                <textarea autoFocus value={val} onChange={(e) => setVal(e.target.value)} rows={2}
                  className="w-full resize-none bg-transparent outline-none" style={{ color: T.white }} />
              ) : <span style={{ color: T.white }}>{m.draft}</span>}
            </div>
            <div className="mt-2.5 flex gap-2">
              <button onClick={() => { onApprove(m.id, editing ? val : m.draft); setEditing(false); }}
                className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold"
                style={{ background: T.em, color: "#04130D" }}>
                <Check size={14} /> Approve &amp; Send
              </button>
              <button onClick={() => { if (editing) onEditSave(m.id, val); setEditing(!editing); }}
                className="flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-xs font-medium"
                style={{ borderColor: T.line, color: T.white }}>
                {editing ? <><Check size={14} /> Save edit</> : <><Pencil size={14} /> Edit Response</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.li>
  );
}

/* ---------- App ---------- */
export default function App() {
  const [autoPilot, setAutoPilot] = useState(true);
  const [voiceSynth, setVoiceSynth] = useState(true);
  const [intervene, setIntervene] = useState(false);
  const [items, setItems] = useState(LIVE ? [] : INITIAL);
  const [stats, setStats] = useState({ autoResolvedPct: 94 });
  const [online, setOnline] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");
  const [activeId, setActiveId] = useState(1);
  const [phase, setPhase] = useState("idle");
  const [lines, setLines] = useState([]);
  const [cmd, setCmd] = useState("");
  const [file, setFile] = useState(false);
  const timers = useRef([]);

  // Poll n8n for the activity log, held queue, stats and switch states.
  useEffect(() => {
    if (!LIVE) return;
    let stop = false;
    const load = async () => {
      try {
        const d = await apiGet();
        if (stop) return;
        setItems(d.items.map((a) => ({ ...a, time: clock(a.time), draft: a.draft || "" })));
        setStats(d.stats);
        if (d.settings) {
          setAutoPilot(d.settings.autoPilot);
          setVoiceSynth(d.settings.voiceSynthesis);
          setIntervene(d.settings.interventionMode);
        }
        setOnline(true);
      } catch { if (!stop) setOnline(false); }
    };
    load();
    const t = setInterval(load, 5000);
    return () => { stop = true; clearInterval(t); };
  }, []);

  const setRemote = (key, setter) => (value) => {
    setter(value);
    if (LIVE) apiPost({ action: "set_setting", key, value }).catch((e) => setError(e.message));
  };

  const pending = items.filter((m) => m.status === "held").length;
  const shown = filter === "all" ? items : items.filter((m) => m.status === "held");
  const active = items.find((m) => m.id === activeId) || items[0];

  const clear = () => { timers.current.forEach(clearTimeout); timers.current = []; };
  useEffect(() => clear, []);
  const later = (fn, ms) => timers.current.push(setTimeout(fn, ms));

  const run = (kind) => {
    clear(); setLines([]); setPhase("processing");
    const script = RESP[kind] || RESP.free;
    later(() => {
      setPhase("speaking");
      script.forEach((l, i) => later(() => setLines((p) => [...p, l]), i * 1700));
      later(() => setPhase("idle"), script.length * 1700 + 1500);
    }, 1400);
  };

  const chip = (c) => { if (c.id === "pause") setRemote("autoPilot", setAutoPilot)(false); run(c.id); };
  const toggleMic = () => {
    if (phase === "listening") run("free");
    else { clear(); setLines([]); setPhase("listening"); }
  };
  const execute = () => {
    if (!cmd.trim() && !file) return;
    setCmd(""); setFile(false); run("free");
  };

  const approve = async (id, text) => {
    const original = items.find((m) => m.id === id);
    setItems((p) => p.map((m) => (m.id === id ? { ...m, status: "sent", draft: text } : m)));
    if (!LIVE) return;
    try {
      await apiPost({ action: text !== original.draft ? "edit" : "approve", id, text });
      setError("");
    } catch (e) {
      setError(e.message);
      setItems((p) => p.map((m) => (m.id === id ? original : m))); // roll back
    }
  };
  const saveEdit = (id, text) => setItems((p) => p.map((m) => (m.id === id ? { ...m, draft: text } : m)));

  const phaseLabel = { idle: "Idle", listening: "Listening", processing: "Processing", speaking: "Speaking" }[phase];
  const fade = { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } };

  return (
    <div className="min-h-screen text-sm" style={{ background: T.bg, color: T.white, fontFamily: SANS,
      backgroundImage: "radial-gradient(900px 500px at 78% -10%, rgba(0,245,160,.09), transparent 60%), radial-gradient(700px 400px at -5% 110%, rgba(245,158,11,.06), transparent 60%)" }}>

      {/* Top bar */}
      <header className="border-b backdrop-blur-xl" style={{ borderColor: T.line, background: "rgba(8,9,12,.7)" }}>
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center gap-x-6 gap-y-3 px-5 py-3.5">
          <div className="flex items-center gap-3">
            <span className="relative flex h-2.5 w-2.5">
              <motion.span className="absolute inline-flex h-full w-full rounded-full" style={{ background: T.em }}
                animate={{ scale: [1, 2.6], opacity: [0.6, 0] }} transition={{ duration: 1.8, repeat: Infinity }} />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full" style={{ background: T.em }} />
            </span>
            <h1 className="text-base font-semibold tracking-tight">
              AURA <span style={{ color: T.em }}>//</span> <span className="font-normal" style={{ color: T.mute }}>VOICE &amp; AGENT CONTROL</span>
            </h1>
          </div>
          <div className="flex flex-wrap gap-2">
            <Switch label="Auto-Pilot" on={autoPilot} onChange={setRemote("autoPilot", setAutoPilot)} />
            <Switch label="Voice Synthesis" on={voiceSynth} onChange={setRemote("voiceSynthesis", setVoiceSynth)} />
            <Switch label="Intervention Mode" on={intervene} onChange={setRemote("interventionMode", setIntervene)} />
          </div>
          <div className="flex flex-wrap gap-2 lg:ml-auto">
            <Stat label="Live Queue" value="0" />
            <Stat label="24h Auto-Resolved" value={`${stats.autoResolvedPct}%`} />
            <Stat label="Pending Review" value={pending} tone={pending ? T.amber : null} />
          </div>
        </div>
      </header>
      {((LIVE && !online) || error) && (
        <div className="px-5 py-2 text-xs" style={{ background: "rgba(245,158,11,.1)", color: T.amber, fontFamily: MONO }}>
          {error || "Can't reach n8n. Check VITE_N8N_BASE_URL and that the workflow is active."}
        </div>
      )}

      <main className="mx-auto grid max-w-[1500px] gap-5 p-5 lg:grid-cols-[35%_1fr]">
        {/* LEFT: stream + interception queue */}
        <section className="flex min-h-[420px] flex-col rounded-xl border" style={{ background: "rgba(17,19,25,.8)", borderColor: T.line }}>
          <div className="flex gap-5 border-b px-4" style={{ borderColor: T.line }}>
            {[["all", "All Activity"], ["held", `Needs Approval (${pending})`]].map(([id, l]) => (
              <button key={id} onClick={() => setFilter(id)} className="relative py-3 text-sm font-medium"
                style={{ color: filter === id ? T.white : T.mute }}>
                {l}
                {filter === id && <motion.span layoutId="tabline" className="absolute inset-x-0 -bottom-px h-0.5"
                  style={{ background: id === "held" ? T.amber : T.em }} />}
              </button>
            ))}
          </div>
          <ul className="flex-1 space-y-2.5 overflow-y-auto p-3.5" style={{ maxHeight: "calc(100vh - 230px)" }}>
            <AnimatePresence mode="popLayout">
              {shown.map((m) => (
                <Card key={m.id} m={m} active={m.id === activeId} onSelect={setActiveId} onApprove={approve} onEditSave={saveEdit} />
              ))}
            </AnimatePresence>
            {!shown.length && <p className="py-12 text-center" style={{ color: T.mute }}>Nothing waiting. The queue is clear.</p>}
          </ul>
        </section>

        {/* RIGHT: voice + command hub */}
        <section className="flex flex-col rounded-xl border" style={{ background: "rgba(17,19,25,.8)", borderColor: T.line }}>
          <div className="flex items-center justify-between border-b px-5 py-3.5" style={{ borderColor: T.line }}>
            <div>
              <div className="text-xs" style={{ color: T.mute }}>Active conversation</div>
              <div className="font-medium">{active ? `${active.who} · ${active.time}` : "None selected"}</div>
            </div>
            <div className="flex items-center gap-2 rounded-md border px-2.5 py-1 text-xs"
              style={{ fontFamily: MONO, borderColor: T.line, color: phase === "idle" ? T.mute : T.em }}>
              <Radio size={12} /> {phaseLabel}
            </div>
          </div>

          {intervene && (
            <div className="border-b px-5 py-2 text-xs"
              style={{ borderColor: T.line, color: T.amber, background: "rgba(245,158,11,.06)", fontFamily: MONO }}>
              Intervention Mode is on: you review every outgoing reply.
            </div>
          )}

          <div className="flex flex-1 flex-col items-center justify-center px-5 py-6">
            <div className="w-full max-w-3xl">
              <button onClick={toggleMic} className="block w-full rounded-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-300"
                aria-label={phase === "listening" ? "Stop listening" : "Start listening"}>
                <Waveform phase={phase} />
              </button>

              <div className="mt-2 h-24 overflow-hidden text-center" style={{ maskImage: "linear-gradient(transparent, #000 30%)" }}>
                <div className="flex h-full flex-col justify-end gap-1">
                  <AnimatePresence initial={false}>
                    {phase === "listening" && <motion.p key="l" {...fade} style={{ color: T.em }}>Listening. Press the wave or the mic to finish.</motion.p>}
                    {phase === "processing" && <motion.p key="p" {...fade} style={{ color: T.mute }}>Working on it...</motion.p>}
                    {phase === "idle" && !lines.length && <motion.p key="i" {...fade} style={{ color: T.mute }}>Press the wave to speak, or pick a quick action.</motion.p>}
                    {phase !== "listening" && lines.slice(-3).map((l, i, arr) => (
                      <motion.p key={l} layout initial={{ opacity: 0, y: 14 }} animate={{ opacity: i === arr.length - 1 ? 1 : 0.4, y: 0 }}
                        style={{ color: i === arr.length - 1 ? T.white : T.mute }}>{l}</motion.p>
                    ))}
                  </AnimatePresence>
                </div>
              </div>

              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {CHIPS.map((c) => (
                  <motion.button key={c.id} whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} onClick={() => chip(c)}
                    className="rounded-md border px-3.5 py-2 text-sm transition-colors hover:border-emerald-400/50"
                    style={{ borderColor: T.line, background: "#0E1016", color: T.white }}>
                    {c.label}
                  </motion.button>
                ))}
              </div>
            </div>
          </div>

          {/* Command console */}
          <div className="border-t p-3.5" style={{ borderColor: T.line }}>
            <AnimatePresence>
              {file && (
                <motion.div {...fade} className="mb-2 flex w-fit items-center gap-2 rounded border px-2 py-1 text-xs"
                  style={{ borderColor: T.line, fontFamily: MONO, color: T.mute }}>
                  <Paperclip size={12} /> invoice-2291.pdf
                  <button onClick={() => setFile(false)} aria-label="Remove attachment"><X size={12} /></button>
                </motion.div>
              )}
            </AnimatePresence>
            <form onSubmit={(e) => { e.preventDefault(); execute(); }}
              className="flex items-center gap-2 rounded-lg border p-1.5 focus-within:border-emerald-400/50"
              style={{ borderColor: T.line, background: "#0C0E13" }}>
              <button type="button" onClick={toggleMic} aria-label="Audio input"
                className="grid h-9 w-9 place-items-center rounded-md"
                style={{ color: phase === "listening" ? "#04130D" : T.mute, background: phase === "listening" ? T.em : "transparent" }}>
                {phase === "listening" ? <Square size={15} /> : <Mic size={17} />}
              </button>
              <button type="button" onClick={() => setFile((f) => !f)} aria-label="Attach file"
                className="grid h-9 w-9 place-items-center rounded-md" style={{ color: file ? T.em : T.mute }}>
                <Paperclip size={17} />
              </button>
              <input value={cmd} onChange={(e) => setCmd(e.target.value)} aria-label="Command"
                placeholder="Instruct assistant or override message..."
                className="min-w-0 flex-1 bg-transparent px-1 text-sm outline-none placeholder:text-gray-500" />
              <button type="submit" className="flex items-center gap-2 rounded-md px-4 py-2 text-xs font-semibold"
                style={{ background: T.em, color: "#04130D" }}>
                Execute <CornerDownLeft size={14} />
              </button>
            </form>
          </div>
        </section>
      </main>
    </div>
  );
}
